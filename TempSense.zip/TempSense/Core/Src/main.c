/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
#define DS18B20_PORT GPIOA
#define TX_PIN GPIO_PIN_8
#define RX_PIN GPIO_PIN_9
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

float temp;
uint8_t Presence;
uint8_t Temp_byte1;
uint8_t Temp_byte2;

extern volatile uint16_t count;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

void Set_Pin_Output(GPIO_TypeDef * GPIO, uint16_t PIN) {
	GPIO_InitTypeDef tempComm = {
		PIN,
		GPIO_MODE_OUTPUT_OD,
		GPIO_SPEED_FREQ_HIGH,
		GPIO_NOPULL
	};
	HAL_GPIO_Init(GPIO, &tempComm);
}

void Set_Pin_Input(GPIO_TypeDef * GPIO, uint16_t PIN) {
	GPIO_InitTypeDef tempComm = {
		PIN,
		GPIO_MODE_INPUT,
		GPIO_SPEED_FREQ_HIGH,
		GPIO_NOPULL
	};
	HAL_GPIO_Init(GPIO, &tempComm);
}

void delay (uint32_t us)
{
    uint16_t start = TIM6->CNT;
    while ((TIM6->CNT - start)<us);
}

uint8_t TempStart (void)
{
	uint8_t Response = 0;
	HAL_GPIO_WritePin(GPIOA, TX_PIN, GPIO_PIN_RESET);  // pull the pin low
	delay(480);   // delay according to datasheet
	
	HAL_GPIO_WritePin(GPIOA, TX_PIN, GPIO_PIN_SET);  // release line
	delay(80);    // delay according to datasheet

	if (!(HAL_GPIO_ReadPin(GPIOA, RX_PIN))) Response = 1;    // if the pin is low i.e the presence pulse is detected
	else Response = 0;

	delay(400); // 480 us delay totally.

	return Response;
}

void TempWrite(uint8_t data)
{

	for (int i=0; i<8; i++)
	{

		if ((data & (1<<i))!=0)  // if the bit is high
		{
			// write 1

			HAL_GPIO_WritePin (DS18B20_PORT, TX_PIN, GPIO_PIN_RESET);  // pull the pin LOW
			delay (1);  // wait for 1 us

			HAL_GPIO_WritePin (DS18B20_PORT, TX_PIN, GPIO_PIN_SET);  // release the pin
			delay (60);  // wait for 60 us
		}

		else  // if the bit is low
		{
			// write 0

			HAL_GPIO_WritePin (DS18B20_PORT, TX_PIN, GPIO_PIN_RESET);  // pull the pin LOW
			delay (60);  // wait for 60 us

			HAL_GPIO_WritePin (DS18B20_PORT, TX_PIN, GPIO_PIN_SET);  // release the pin
		}
		delay(4); // recovery delay
	}
}

uint8_t TempRead(void)
{
	uint8_t value=0;

	for (int i=0;i<8;i++)
	{

		HAL_GPIO_WritePin (GPIOA, TX_PIN, GPIO_PIN_RESET);  // pull the data pin LOW
		delay (1);  // wait for 2 us
		
		HAL_GPIO_WritePin (GPIOA, TX_PIN, GPIO_PIN_SET);  // release line
		delay(15); // recovery delay
		
		if (HAL_GPIO_ReadPin(GPIOA, RX_PIN))  // if the pin is HIGH
		{
			value |= 1<<i;  // read = 1
		}
		delay (60);  // wait for 60 us
	}
	return value;
}

float ConvertTemp(uint8_t LSB, uint8_t MSB) {
	float result = 0;
	
	if (LSB & (1 << 0)) {
		result = result + 0.0625;
	}
	if (LSB & (1 << 1)) {
		result = result + 0.125;
	}
	if (LSB & (1 << 2)) {
		result = result + 0.25;
	}
	if (LSB & (1 << 3)) {
		result = result + 0.5;
	}
	if (LSB & (1 << 4)) {
		result = result + 1;
	}
	if (LSB & (1 << 5)) {
		result = result + 2;
	}
	if (LSB & (1 << 6)) {
		result = result + 4;
	}
	if (LSB & (1 << 7)) {
		result = result + 8;
	}
	
	if (MSB & (1 << 0)) {
		result = result + 16;
	}
	if (MSB & (1 << 1)) {
		result = result + 32;
	}
	if (MSB & (1 << 2)) {
		result = result + 64;
	}
	if (MSB & (1 << 3)) {
		result = -result;
	}
	
	return result;
	
}

void pulse(uint32_t pause) {
	HAL_GPIO_WritePin (GPIOA, TX_PIN, GPIO_PIN_RESET);  // pull the data pin LOW
	delay(pause);
	HAL_GPIO_WritePin (GPIOA, TX_PIN, GPIO_PIN_SET);  // release line
	delay(pause);
}

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  /* USER CODE BEGIN 2 */
	
	// Enable RCC
	__HAL_RCC_TIM6_CLK_ENABLE();
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();
	
	// Configure LEDs
	GPIO_InitTypeDef LEDs = {
		GPIO_PIN_9 | GPIO_PIN_8 | GPIO_PIN_7 | GPIO_PIN_6,
		GPIO_MODE_OUTPUT_PP,
		GPIO_SPEED_FREQ_LOW,
		GPIO_NOPULL
	};
	
	HAL_GPIO_Init(GPIOC, &LEDs);
	
	/*
	GPIO_InitTypeDef tempTX = {
		GPIO_PIN_1,
		GPIO_MODE_OUTPUT_OD,
		GPIO_SPEED_FREQ_HIGH,
		GPIO_NOPULL
	};
	HAL_GPIO_Init(GPIOA, &tempTX);
	
	GPIO_InitTypeDef tempRX = {
		GPIO_PIN_2,
		GPIO_MODE_INPUT,
		GPIO_SPEED_FREQ_HIGH,
		GPIO_NOPULL
	};
	HAL_GPIO_Init(GPIOA, &tempRX);
	*/
	Set_Pin_Output(GPIOA, TX_PIN);
	Set_Pin_Input(GPIOA, RX_PIN);
	
	// Microsecond timer setup
	TIM6->PSC = 7;
	TIM6->ARR = 0xFFFF;
	
	// TIM6->DIER |= TIM_DIER_UIE;
	
	TIM6->CR1 |= TIM_CR1_CEN;
	
	// Enable the interrupt
	// NVIC_EnableIRQ(TIM6_IRQn);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */
		Presence = TempStart (); // Reset pulse
		HAL_Delay(1);
		TempWrite (0xCC);  // skip ROM
		TempWrite (0x44);  // Issue temp convert request
		HAL_Delay (800);	 // Wait for temp conversion to finish

		Presence = TempStart(); // Reset pulse
		
		delay(250);
		TempWrite (0xCC);  // skip ROM
		delay(250);
		TempWrite (0xBE);  // Read Scratch-pad
		delay(250);

		Temp_byte1 = TempRead(); // temp LSB
		delay(250);
		Temp_byte2 = TempRead(); // temp MSB
		delay(250);
		
		TempStart(); // Issue reset to stop reading data bytes
		
		temp = ConvertTemp(Temp_byte1, Temp_byte2);
		
		HAL_Delay(10);
		
		
		/*
		PC6 - RED
		PC7 - BLUE
		PC8 - ORANGE
		PC9 - GREEN
		*/
		
		if (temp < 21) {
			HAL_GPIO_WritePin(GPIOC,GPIO_PIN_7, GPIO_PIN_SET);
		} else {
			HAL_GPIO_WritePin(GPIOC,GPIO_PIN_7, GPIO_PIN_RESET);
		}
		if (temp > 21) {
			HAL_GPIO_WritePin(GPIOC,GPIO_PIN_9, GPIO_PIN_SET);
		} else {
			HAL_GPIO_WritePin(GPIOC,GPIO_PIN_9, GPIO_PIN_RESET);
		}
		if (temp > 30) {
			HAL_GPIO_WritePin(GPIOC,GPIO_PIN_8, GPIO_PIN_SET);
		} else {
			HAL_GPIO_WritePin(GPIOC,GPIO_PIN_8, GPIO_PIN_RESET);
		}
		if (temp > 50) {
			HAL_GPIO_WritePin(GPIOC,GPIO_PIN_6, GPIO_PIN_SET);
		} else {
			HAL_GPIO_WritePin(GPIOC,GPIO_PIN_6, GPIO_PIN_RESET);
		}
		
    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

